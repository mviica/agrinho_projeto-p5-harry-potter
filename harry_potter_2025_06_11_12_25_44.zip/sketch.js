let spells = []; // Array para armazenar os feitiços
let wand; // A varinha mágica
let spellColors = ['#FF4500', '#00BFFF', '#FFFF00', '#8A2BE2']; // Cores diferentes para os feitiços
let wandMoveSpeed = 0.5; // Velocidade da varinha

function setup() {
  createCanvas(800, 600);
  noStroke();
  wand = new Wand(width / 2, height - 100);
}

function draw() {
  background(0); // Fundo escuro, como uma noite mágica
  
  // Desenhar o castelo ao fundo
  drawCastle();
  
  // Desenhando o céu estrelado
  drawStars();
  
  // Desenhando a varinha
  wand.show();

  // Atualizar e mostrar todos os feitiços disparados
  for (let i = 0; i < spells.length; i++) {
    spells[i].update();
    spells[i].show();
  }

  // Feitiços se dissipando após um tempo
  removeExpiredSpells();
}

// Função para desenhar estrelas no céu
function drawStars() {
  fill(255, 255, 255, 100); // Cor branca com transparência
  for (let i = 0; i < 200; i++) {
    let x = random(width);
    let y = random(height);
    let size = random(1, 3);
    ellipse(x, y, size, size);
  }
}

// Função para desenhar o castelo
function drawCastle() {
  // Corpo do castelo
  fill(100, 100, 100);
  rect(100, 250, 600, 250); // Base do castelo

  // Torres
  fill(80, 80, 80);
  rect(150, 150, 50, 100);  // Torre esquerda
  rect(600, 150, 50, 100);  // Torre direita

  // Telhados das torres
  fill(150, 50, 50);
  triangle(150, 150, 175, 100, 200, 150); // Telhado torre esquerda
  triangle(600, 150, 625, 100, 650, 150); // Telhado torre direita

  // Porta do castelo
  fill(150, 100, 50);
  rect(375, 400, 50, 100);  // Porta central

  // Janelas das torres
  fill(200, 200, 255);
  rect(155, 170, 20, 20);  // Janela torre esquerda
  rect(625, 170, 20, 20);  // Janela torre direita
}

// Função que será chamada quando pressionar o mouse (simulando o disparo de um feitiço)
function mousePressed() {
  // Escolher aleatoriamente uma cor para o feitiço
  let color = random(spellColors);
  let spell = new Spell(wand.x, wand.y, random(5, 10), random(TWO_PI), random(15, 25), color);
  spells.push(spell);
}

// Classe para a varinha mágica
class Wand {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.length = 100;
    this.angle = 0;
    this.noiseOffset = random(1000);  // Para gerar um movimento fluido de varinha
  }

  // Desenha a varinha na tela, que segue a posição do mouse
  show() {
    this.x = mouseX;
    this.y = mouseY;

    // Varinha com movimento sutil e fluido
    this.angle += sin(frameCount * wandMoveSpeed) * 0.1 + noise(this.noiseOffset) * 0.05;
    this.noiseOffset += 0.1;

    fill(139, 69, 19);  // Cor marrom para a varinha
    push();
    translate(this.x, this.y);
    rotate(this.angle);  // Rotacionar a varinha para animar
    rect(-5, -this.length / 2, 10, this.length);  // Representação da varinha com um retângulo
    pop();
  }
}

// Classe para os feitiços
class Spell {
  constructor(x, y, speed, angle, size, color) {
    this.x = x;
    this.y = y;
    this.speed = speed;  // Velocidade do feitiço
    this.angle = angle;  // Direção do feitiço
    this.size = size;  // Tamanho do feitiço
    this.color = color;  // Cor do feitiço
    this.lifetime = 255;  // Vida útil do feitiço (a intensidade vai diminuir)
    this.trail = []; // Array para armazenar o rastro do feitiço
    this.exploded = false; // Flag para verificar se o feitiço já explodiu
    this.particles = []; // Array para armazenar as partículas da explosão
  }

  // Atualiza a posição do feitiço
  update() {
    if (!this.exploded) {
      this.x += cos(this.angle) * this.speed; // Movimento na direção do ângulo
      this.y += sin(this.angle) * this.speed;

      // Diminuindo a intensidade do feitiço com o tempo
      this.lifetime -= 4;

      // Aumentando o tamanho do feitiço à medida que avança
      this.size += 0.1;

      // Adicionando o ponto atual à lista de rastros
      this.trail.push({ x: this.x, y: this.y, lifetime: this.lifetime });

      // Remover o rastro que já desapareceu
      if (this.trail.length > 10) {
        this.trail.shift();
      }

      // Se a vida do feitiço acabar, ele explode
      if (this.lifetime <= 0) {
        this.explode();
      }
    } else {
      // Atualiza e desenha as partículas da explosão
      for (let i = this.particles.length - 1; i >= 0; i--) {
        this.particles[i].update();
        this.particles[i].show();
        if (this.particles[i].life <= 0) {
          this.particles.splice(i, 1);  // Remove partículas que desapareceram
        }
      }
    }
  }

  // Função para desenhar o feitiço na tela com rastro
  show() {
    // Desenhando o rastro do feitiço
    for (let i = 0; i < this.trail.length; i++) {
      let alpha = map(i, 0, this.trail.length, 0, 255);
      fill(this.color + hex(alpha, 2));  // Cor com transparência
      ellipse(this.trail[i].x, this.trail[i].y, this.size - i, this.size - i);
    }

    // Desenhando o feitiço principal
    fill(this.color + hex(this.lifetime, 2));  // Cor do feitiço com transparência
    ellipse(this.x, this.y, this.size, this.size);
  }

  // Função para explodir o feitiço em partículas
  explode() {
    for (let i = 0; i < 50; i++) {
      let particle = new Particle(this.x, this.y, random(2, 5), random(TWO_PI), random(10, 30), this.color);
      this.particles.push(particle);
    }
    this.exploded = true;  // Marca que o feitiço já explodiu
  }
}

// Classe para as partículas da explosão
class Particle {
  constructor(x, y, speed, angle, size, color) {
    this.x = x;
    this.y = y;
    this.speed = speed;
    this.angle = angle;
    this.size = size;
    this.color = color;
    this.life = 255;  // Vida útil da partícula
  }

  // Atualiza a posição e o estado da partícula
  update() {
    this.x += cos(this.angle) * this.speed;
    this.y += sin(this.angle) * this.speed;
    this.life -= 5;  // A partícula vai perdendo intensidade
  }

  // Desenha a partícula
  show() {
    fill(this.color + hex(this.life, 2));  // Cor com transparência
    noStroke();
    ellipse(this.x, this.y, this.size, this.size);
  }
}

// Função para remover feitiços que já desapareceram
function removeExpiredSpells() {
  for (let i = spells.length - 1; i >= 0; i--) {
    if (spells[i].lifetime <= 0 && spells[i].particles.length === 0) {
      spells.splice(i, 1);  // Remove o feitiço da lista quando a vida dele chega a zero e as partículas sumiram
    }
  }
}
